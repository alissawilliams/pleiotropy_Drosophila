#!/bin/bash
#SBATCH --mail-type=ALL
#SBATCH --mail-user=alissa.williams@vanderbilt.edu
#SBATCH --nodes=2   
#SBATCH --ntasks=16
#SBATCH --time=14-00:00:00
#SBATCH --error=plei_genes_codeml.err
#SBATCH --output=plei_genes_codeml.out

for i in `ls *.fas | sed 's/\..*//'`; do sed -i "/seqfile =/ s/= .*/= $i.fas/" control_file; sed -i "/outfile =/ s/= .*/= $i.site.result.txt/" control_file; /home/willa27/paml4.9j/bin/codeml control_file; done