#!/bin/bash
#SBATCH --mail-type=ALL
#SBATCH --mail-user=alissa.williams@vanderbilt.edu
#SBATCH --nodes=1   
#SBATCH --time=2-00:00:00
#SBATCH --error=change_names.err
#SBATCH --output=change_names.out

for file in *.fas ; 
	do 
		sed -i 's/>Dana.*/>Drosophila_ananassae/' $file;
		sed -i 's/>Dere.*/>Drosophila_erecta/' $file;
		sed -i 's/>Dgri.*/>Drosophila_grimshawi/' $file;
		sed -i 's/>Dmel.*/>Drosophila_melanogaster/' $file;
		sed -i 's/>Dmoj.*/>Drosophila_mojavensis/' $file;
		sed -i 's/>Dper.*/>Drosophila_persimilis/' $file;
		sed -i 's/>Dpse.*/>Drosophila_pseudoobscura/' $file;
		sed -i 's/>Dsec.*/>Drosophila_sechellia/' $file;
		sed -i 's/>Dsim.*/>Drosophila_simulans/' $file;
		sed -i 's/>Dvir.*/>Drosophila_virilis/' $file;
		sed -i 's/>Dwil.*/>Drosophila_willistoni/' $file;
		sed -i 's/>Dyak.*/>Drosophila_yakuba/' $file;
	done
