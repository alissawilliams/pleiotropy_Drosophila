#!/bin/bash
#SBATCH --mail-type=ALL
#SBATCH --mail-user=alissa.williams@vanderbilt.edu
#SBATCH --nodes=2   
#SBATCH --ntasks=16
#SBATCH --time=14-00:00:00
#SBATCH --error=plei_genes_codeml.err
#SBATCH --output=plei_genes_codeml.out

for i in `ls *.fasta.gb.fas | sed 's/\..*//'`; do sed -i "/seqfile =/ s/= .*/= $i.fasta.gb.fas/" control_file.txt; sed -i "/outfile =/ s/= .*/= $i.site.result.txt/" control_file.txt; /home/willa27/paml4.9j/bin/codeml control_file.txt; done